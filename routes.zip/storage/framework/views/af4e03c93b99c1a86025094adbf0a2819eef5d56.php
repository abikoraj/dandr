
<?php $__env->startSection('title', 'Expenses'); ?>
<?php $__env->startSection('head-title', 'Expenses'); ?>
<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('calender/nepali.datepicker.v3.2.min.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('backend/plugins/select2/select2.css')); ?>" />
<?php $__env->stopSection(); ?>
<?php $__env->startSection('toobar'); ?>

    <?php echo $__env->make('admin.expense.add', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="col lg-2">
        <div class="pt-2 pb-2">
            <button class="btn btn-primary mr-1" data-toggle="modal" data-target="#addModal">Add Expense</button>
            <a href="<?php echo e(route('admin.expense.category')); ?>" class="btn btn-secondary">Expense Categories</a>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

    <div class="row mb-3">
        <div class="col lg-12">
            <select name="cat_id" id="cat" class="form-control show-tick ms select2" >
                <option value="-1">All</option>
                <?php $__currentLoopData = \App\Models\Expcategory::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($item->id); ?>"><?php echo e($item->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <small>Select category to display category wise expense</small>
        </div>
    </div>
    <?php echo $__env->make('admin.layouts.daterange', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="row">
        <div class="col-md-3">
            <span class="btn btn-primary w-100" onclick="loadExp()"> Load Expenses</span>
        </div>

    </div>
    <hr>
    <div class="table-responsive" id="expenseData">
        
    </div>






<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <script src="<?php echo e(asset('backend/plugins/select2/select2.min.js')); ?>"></script>
    <script>
        // TODO expenses
        function initEdit(title, id) {
            win.showPost("Edit Expense - " + title, '<?php echo e(route('admin.expense.edit')); ?>', {
                "id": id
            })
        }

        function saveData(e) {
            e.preventDefault();
            var bodyFormData = new FormData(document.getElementById('form_validation'));
            axios({
                    method: 'post',
                    url: '<?php echo e(route('admin.expense.add')); ?>',
                    data: bodyFormData,
                    headers: {
                        'Content-Type': 'multipart/form-data'
                    }
                })
                .then(function(response) {
                    console.log(response);
                    showNotification('bg-success', 'Expense added successfully!');
                    add_another = document.getElementById('add_another').checked;
                    if (!add_another) {
                        debugger;
                        $("#addModal").modal('hide');
                    }
                    $('#form_validation').trigger("reset");
                    $('#expenseData').prepend(response.data);
                    document.getElementById('add_another').checked = add_another;

                })
                .catch(function(response) {
                    //handle error
                    console.log(response);
                });
        }

        // edit data
        function editData(e) {
            e.preventDefault();
            var rowid = $('#eid').val();
            var bodyFormData = new FormData(document.getElementById('editform'));
            axios({
                    method: 'post',
                    url: '<?php echo e(route('admin.expense.update')); ?>',
                    data: bodyFormData,
                    headers: {
                        'Content-Type': 'multipart/form-data'
                    }
                })
                .then(function(response) {
                    win.hide();
                })
                .catch(function(response) {
                    //handle error
                    console.log(response);
                
                });
        }



        // delete
        function removeData(id) {
            var dataid = id;
            if (confirm('Are you sure?')) {
                axios({
                        method: 'post',
                        url: '<?php echo e(route('admin.expense.delete')); ?>',
                        data: {
                            "id": id
                        }
                    })
                    .then(function(response) {
                        // console.log(response.data);
                        $('#expense-' + dataid).remove();
                        showNotification('bg-danger', 'Deleted Successfully !');
                    })
                    .catch(function(response) {

                        showNotification('bg-danger', 'You do not have authority to delete!');
                        //handle error
                        console.log(response);
                    });
            }
        }

        window.onload = function() {
            $('#type').val(1).change();
            loadExp();
        };





        function loadExp() {
            $('#expenseData').html('');
            var data={
                'year':$('#year').val(),
                'month':$('#month').val(),
                'session':$('#session').val(),
                'week':$('#week').val(),
                'date1':$('#date1').val(),
                'date2': $('#date2').val(),
                'type':$('#type').val(),
                'cat_id':$('#cat').val()
            };
            axios({
                    method: 'post',
                    url: '<?php echo e(route('admin.expense.load')); ?>',
                    data: data
                })
                .then(function(response) {
                    // console.log(response.data);
                    $('#expenseData').html(response.data);
                    initTableSearch('sid', 'expenseData', ['name']);
                })
                .catch(function(response) {
                    //handle error
                    console.log(response);
                });
        }


        $('#cat').change(function() {
            loadExp();
        });

        s_id = 0;

    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\needtechnosoft 2\OneDrive\Desktop\laravel pojects\dairy\resources\views/admin/expense/index.blade.php ENDPATH**/ ?>