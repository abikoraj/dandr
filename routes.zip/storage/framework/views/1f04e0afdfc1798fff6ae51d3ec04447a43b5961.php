<tr id="milk-<?php echo e($d->no); ?>" data-m_amount="<?php echo e($d->m_amount??0); ?>" data-e_amount="<?php echo e($d->e_amount??0); ?>">
    <td><?php echo e($d->no); ?></td>
    <td id="m_milk-<?php echo e($d->no); ?>"  ><?php echo e($d->m_amount??0); ?></td>
    <td id="e_milk-<?php echo e($d->no); ?>" ><?php echo e($d->e_amount??0); ?></td>
</tr>
<?php /**PATH C:\Users\needtechnosoft 2\OneDrive\Desktop\laravel pojects\dairy\resources\views/admin/milk/single.blade.php ENDPATH**/ ?>