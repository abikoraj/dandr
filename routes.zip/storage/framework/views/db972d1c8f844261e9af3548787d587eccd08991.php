<?php $__currentLoopData = $milkdatas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php if($d->user()!=null): ?>

    <tr  id="milk-<?php echo e($d->user()->no); ?>" data-m_amount="<?php echo e($d->m_amount??0); ?>" data-e_amount="<?php echo e($d->e_amount??0); ?>">
        <td><?php echo e($d->user()->no); ?></td>
        <td id="m_milk-<?php echo e($d->user()->no); ?>"  ><?php echo e($d->m_amount??0); ?></td>
        <td id="e_milk-<?php echo e($d->user()->no); ?>" ><?php echo e($d->e_amount??0); ?></td>
    </tr>
<?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH C:\Users\needtechnosoft 2\OneDrive\Desktop\laravel pojects\dairy\resources\views/admin/milk/dataload.blade.php ENDPATH**/ ?>