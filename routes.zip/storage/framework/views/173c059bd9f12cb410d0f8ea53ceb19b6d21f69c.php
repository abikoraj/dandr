<?php $__currentLoopData = $sell; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $itemsell): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php if($itemsell->user!=null): ?>
<tr id="itemsell-<?php echo e($itemsell->id); ?>" data-id="<?php echo e($itemsell->user->no); ?>" data-item_number="<?php echo e($itemsell->item->number); ?>">
    <td><input type="checkbox" class="ids" value="<?php echo e($itemsell->id); ?>"> <?php echo e($itemsell->user->no); ?></td>
    <td><?php echo e($itemsell->item->title); ?></td>
    <td><?php echo e($itemsell->rate); ?></td>
    <td><?php echo e($itemsell->qty); ?></td>
    <td><?php echo e($itemsell->total); ?></td>
    <td><?php echo e($itemsell->paid); ?></td>
    <td><?php echo e($itemsell->due); ?></td>
    <td>
        <button class="badge badge-danger" onclick="removeData(<?php echo e($itemsell->id); ?>);">Delete</button>
    </td>
</tr>
<?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH C:\Users\needtechnosoft 2\OneDrive\Desktop\laravel pojects\dairy\resources\views/admin/sellitem/list.blade.php ENDPATH**/ ?>