<hr>
<div id="print" class="p-2">
    <div class="p-3">
        <div style="font-weight: 800" class="d-flex justify-content-start">
            <span class="mr-4">
                Farmer No : <?php echo e($farmer1->no); ?>

            </span>
            <span class="mr-4">

                 Name : <?php echo e($farmer1->name); ?>

            </span>
            <span class="mr-4">
                Phone no : <?php echo e($farmer1->phone); ?>

            </span>
        </div style="font-weight: 800">
        <div style="font-weight: 800" class="d-flex justify-content-start">
            <span class="mr-4">

                Year : <?php echo e($data['year']); ?>

            </span>
            <span class="mr-4">

                Month : <?php echo e($data['month']); ?>

            </span>
            <span class="mr-4">

                Session : <?php echo e($data['session']); ?>

            </span>
        </div style="font-weight: 800">
    </div>
    <div class="row ">
        <div class="col-md-6">
            <div style="border: 1px solid rgb(136, 126, 126); padding:1rem;">
                
                <div id="milk-data">
                    <style>
                        td,th{
                            border:1px solid black;
                        }
                        table{
                            width:100%;
                            border-collapse: collapse;
                        }
                        thead {display: table-header-group;}
                        tfoot {display: table-header-group;}
                    </style>
                    <strong>Milk Data</strong>
                    <hr>
                    <table class="table table-bordered table-striped table-hover js-basic-example dataTable">
                        <tr>
                            <th>Date</th>
                            <th>Morning (L)</th>
                            <th>Evening (L)</th>
                            <td class="d-print-none"></td>
                        </tr>
                        <?php
                            $m = 0;
                            $e = 0;
                        ?>
                            <?php $__currentLoopData = $milkData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $milk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e(_nepalidate($milk->date)); ?></td>
                                <td><?php echo e($milk->m_amount); ?></td>
                                <td><?php echo e($milk->e_amount); ?></td>
                                <td class="d-print-none">
                                    <button class="btn btn-primary btn-sm" data-milk="<?php echo e($milk->toJson()); ?>" onclick="showMilkUpdate(this)">
                                        Edit
                                    </button>
                                    <button class="btn btn-danger btn-sm" data-milk="<?php echo e($milk->toJson()); ?>" onclick="delMilkData(this);">
                                        delete
                                    </button>
                                </td>
                            </tr>
                            <?php
                                $m += $milk->m_amount;
                                $e += $milk->e_amount;
                            ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><strong>Total</strong></td>
                                <td><?php echo e($m); ?></td>
                                <td><?php echo e($e); ?></td>

                            </tr>
                    </table>
                        <strong>Grand Total : <?php echo e($farmer1->milkamount); ?></strong> (Liter) <br>

                </div>
            </div>

        </div>
        <div class="col-md-6">
            <div style="border: 1px solid rgb(136, 126, 126); padding:1rem;">

                <div id="snffat-data">
                    <style>
                        td,th{
                            border:1px solid black;
                        }
                        table{
                            width:100%;
                            border-collapse: collapse;
                        }
                        thead {display: table-header-group;}
                        tfoot {display: table-header-group;}
                    </style>
                    <strong>Snf & Fats </strong>
                    <hr>
                    <table class="table table-bordered table-striped table-hover js-basic-example dataTable">
                        <tr>
                            <th>Date</th>
                            <th>Snf (%)</th>
                            <th>Fats (%)</th>
                            <td class="d-print-none">

                            </td>
                        </tr>
                            <?php $__currentLoopData = $snfFats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sf): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                <td><?php echo e(_nepalidate($sf->date)); ?></td>
                                    <td><?php echo e($sf->snf); ?></td>
                                    <td><?php echo e($sf->fat); ?></td>
                                    <td class="d-print-none">
                                        <button class="btn btn-primary btn-sm" data-snffat="<?php echo e($sf->toJson()); ?>" onclick="showSnfFatUpdate(this)">
                                            Edit
                                        </button>
                                        <button class="btn btn-danger btn-sm" data-snffat="<?php echo e($sf->toJson()); ?>" onclick="delSnfFat(this);">
                                            delete
                                        </button>
                                    </td>
                                </tr>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </table>
                    <?php
                        if($milk_rate != null){
                            $rate_ = $milk_rate->rate;
                        }else{
                            $rate_ = round($farmer1->milkrate,2);
                        }
                    ?>
                    <div style="display: flex">
                        <div style="flex:8;padding:10px;">
                            <strong>Snf Average : <?php echo e(round($farmer1->snfavg,2)); ?></strong> <br>
                            <strong>Milk Total : <?php echo e($farmer1->milkamount); ?> </strong><br>
                            <strong>Per Liter Rate : <?php echo e($rate_); ?> </strong> <br>
                                <strong>Amount : <?php echo e($farmer1->totalamount); ?> </strong><br>
                                <?php if($farmer1->farmer()->usetc): ?>
                                    <strong>+TS Commission (<?php echo e((float)($center->tc)); ?>%) : <?php echo e($farmer1->tc); ?></strong> <br>
                                <?php endif; ?>
                                <?php if($farmer1->farmer()->usecc): ?>
                                    <strong>+Cooling Cost: <?php echo e($farmer1->cc); ?></strong>
                                <?php endif; ?>
                                <hr>
                                <strong>Total Amount: <?php echo e($farmer1->grandtotal); ?></strong>
                        </div>
                        <div style="flex:4;padding:10px;">
                            <strong>Fat Average : <?php echo e(round($farmer1->fatavg,2)); ?></strong>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        

        <?php if(count($farmer1->ledger)>0): ?>
            <div class="col-md-12 mt-3">
                <div style="border: 1px solid rgb(136, 126, 126); padding:1rem;">

                    <div id="ledger-data">
                        <style>
                            @media  print {
                                td{
                                    font-size: 1.2rem !important;
                                    font-weight: 600 !important;
                                }


                                th:last-child, td:last-child {
                                    display: none;
                                }

                            }
                            td,th{
                                border:1px solid black !important;
                                padding:2px !important;
                                font-weight: 600 !important;
                            }

                            table{
                                width:100%;
                                border-collapse: collapse;
                            }
                            thead {display: table-header-group;}
                            tfoot {display: table-header-group;}
                        </style>
                        <strong>Ledger</strong>
                        <hr>
                        <table class="table table-bordered table-striped table-hover js-basic-example dataTable">
                            <tr>
                                <th>Date</th>
                                <th>Particular</th>
                                <th>Cr. (Rs.)</th>
                                <th>Dr. (Rs.)</th>
                                <th>Balance (Rs.)</th>
                                <th class="d-print-none"></th>
                            </tr>

                            <?php $__currentLoopData = $farmer1->ledger; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $l): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e(_nepalidate($l->date)); ?></td>
                                    <td><?php echo e($l->title); ?></td>

                                    <td>
                                        <?php if($l->type==1): ?>
                                            <?php echo e((float)$l->amount); ?>

                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php if($l->type==2): ?>
                                        <?php echo e((float)$l->amount); ?>

                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php echo e($l->dr>0 ?"Dr. ".(float)$l->dr:""); ?>


                                        <?php echo e($l->cr>0 ?"Cr. ".(float)$l->cr:""); ?>


                                        <?php echo e(($l->cr==0 || $l->cr==null) && ($l->dr==0 || $l->dr==null)?"--":""); ?>

                                    </td>
                                    <td class="d-print-none">
                                        
                                        <button  onclick="initEditLedger('<?php echo e($l->title); ?>',<?php echo e($l->id); ?>);">Edit</button>
                                        <button  onclick="deleteLedger(<?php echo e($l->id); ?>,loadData);">Delete</button>
                                           
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </table>
                    </div>
                </div>
            </div>
        <?php endif; ?>

        <div class="col-md-12">

            <hr>
            <h5 class="font-weight-bold">
                Session Summary
            </h5>
            <hr>

            <div class="report p-2">
                <table class="table">
                    <tr>
                        <th>
                            Total Milk
                        </th>
                        <th>
                            Fat
                        </th>
                        <th>
                            Snf
                        </th>
                        <th>
                            Rate
                        </th>
                        <?php if($farmer1->cc>0 || $farmer1->tc>0): ?>
                            <th>
                                Milk Total
                            </th>
                            <?php if($farmer1->farmer()->usetc): ?>
                            <th>
                                TS
                            </th>
                            <?php endif; ?>
                            <?php if($farmer1->farmer()->usecc): ?>
                            <th>
                                Cooling Cost
                            </th>
                            <?php endif; ?>
                            <th>
                                Total
                            </th>
                        <?php else: ?>
                            <th>
                                Total
                            </th>
                        <?php endif; ?>
                        <?php if(env('hasextra',0)==1): ?>
                            <th>Bonus</th>
                        <?php endif; ?>
                        <th>Purchase</th>
                        <th>Payment</th>
                        <th>Avance</th>
                        <th>
                            Prev Balance
                        </th>
                        <th>
                            Prev Due
                        </th>
                        <th>
                            Paid
                        </th>
                        <th>Net Total</th>
                        <th>Due Balance</th>
                        <th>

                        </th>
                    </tr>
                    <tr>
                        <td>
                            <?php echo e($farmer1->milkamount); ?>

                        </td>
                        <td>
                            <?php echo e($farmer1->fatavg); ?>

                        </td>
                        <td>
                            <?php echo e($farmer1->snfavg); ?>

                        </td>
                        <td>
                            <?php if($milk_rate != null): ?>
                              <?php echo e($milk_rate->rate); ?>

                            <?php else: ?>
                               <?php echo e($farmer1->milkrate); ?>

                            <?php endif; ?>

                        </td>
                        <?php if($farmer1->cc>0 || $farmer1->tc>0): ?>
                            <th>
                                <?php echo e($farmer1->totalamount); ?>

                            </th>
                            <?php if($farmer1->farmer()->usetc): ?>
                            <th>
                                <?php echo e($farmer1->tc); ?>

                            </th>
                            <?php endif; ?>
                            <?php if($farmer1->farmer()->usecc): ?>
                            <th>
                                <?php echo e($farmer1->cc); ?>

                            </th>
                            <?php endif; ?>
                            <th>
                                <?php echo e($farmer1->grandtotal); ?>

                            </th>
                        <?php else: ?>
                            <th>
                                <?php echo e($farmer1->grandtotal); ?>


                            </th>
                        <?php endif; ?>
                        <?php if(env('hasextra',0)==1): ?>
                            <td> <?php echo e($farmer1->bonus); ?>   </td>

                        <?php endif; ?>
                        <td>
                            <?php echo e($farmer1->due); ?>

                        </td>
                        <td>
                            <?php echo e($farmer1->fpaid); ?>

                        </td>
                        <td>
                            <?php echo e($farmer1->advance); ?>

                        </td>
                        <td>
                            <?php echo e($farmer1->prevbalance); ?>

                        </td>
                        <td>
                            <?php echo e($farmer1->prevdue); ?>

                        </td>
                        <td><?php echo e($farmer1->paidamount); ?></td>


                        <td>
                            <?php echo e($farmer1->nettotal); ?>

                        </td>
                        <td>
                            <?php echo e($farmer1->balance); ?>

                        </td>
                        <td>
                            <?php if($farmer1->old==false): ?>
                            <form action="<?php echo e(route('admin.report.farmer.single.session')); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <input type="hidden" name="year" value="<?php echo e($data['year']); ?>">
                                <input type="hidden" name="month" value="<?php echo e($data['month']); ?>">
                                <input type="hidden" name="session" value="<?php echo e($data['session']); ?>">
                                <input type="hidden" name="id" value="<?php echo e($farmer1->id); ?>">
                                <input type="hidden" name="snf" value="<?php echo e($farmer1->snfavg); ?>">
                                <input type="hidden" name="fat" value="<?php echo e($farmer1->fatavg); ?>">
                                <input type="hidden" name="rate" value=" <?php echo e($farmer1->milkrate); ?>">
                                <input type="hidden" name="milk" value="<?php echo e($farmer1->milkamount); ?>">
                                <input type="hidden" name="total" value=" <?php echo e($farmer1->total); ?>">
                                <input type="hidden" name="grandtotal" value=" <?php echo e($farmer1->grandtotal); ?>">
                                <input type="hidden" name="cc" value=" <?php echo e($farmer1->cc); ?>">
                                <input type="hidden" name="tc" value=" <?php echo e($farmer1->tc); ?>">
                                <input type="hidden" name="due" value=" <?php echo e($farmer1->due); ?>">
                                <input type="hidden" name="bonus" value=" <?php echo e($farmer1->bonus); ?>">
                                <input type="hidden" name="advance" value=" <?php echo e($farmer1->advance); ?>">
                                <input type="hidden" name="prevdue" value=" <?php echo e($farmer1->prevdue); ?>">
                                <input type="hidden" name="nettotal" value=" <?php echo e($farmer1->nettotal); ?>">
                                <input type="hidden" name="balance" value=" <?php echo e($farmer1->balance); ?>">
                                <input type="hidden" name="prevbalance" value=" <?php echo e($farmer1->prevbalance); ?>">
                                <input type="hidden" name="paidamount" value=" <?php echo e($farmer1->paidamount); ?>">
                                <input type="hidden" name="fpaid" value=" <?php echo e($farmer1->fpaid); ?>">
                                <label for=>Session Close Date</label>
                                <input type="text" name="date" id="closedate" readonly required>
                                <button class="btn btn-sm btn-success">Close Session</button>
                            </form>
                             <?php else: ?>
                                Session Closed
                            <?php endif; ?>
                        </td>
                    </tr>
                </table>
            </div>
        </div>
    </div>
</div>
<?php /**PATH C:\Users\needtechnosoft 2\OneDrive\Desktop\laravel pojects\dairy\resources\views/admin/farmer/detail/index.blade.php ENDPATH**/ ?>