<div class="row mt-4 ">
    <div class="col-md-12">
        <div style="border: 1px solid rgb(136, 126, 126); padding:1rem;">
            <strong>Paid Salary List For This Month</strong>
            <hr>
            <table class="table table-bordered table-striped table-hover js-basic-example dataTable">
                <tr>
                    <th>Date</th>
                    <th>Employee</th>
                    <th>Amount (Rs.)</th>
                </tr>
                <?php if(count($salary)>0): ?>
                <?php
                    $total = 0;
                ?>
                <?php $__currentLoopData = $salary; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e(_nepalidate($item->date)); ?></td>
                        <td><?php echo e($item->user->name); ?></td>
                        <td><?php echo e($item->amount); ?></td>
                        <input type="hidden" value="<?php echo e($item->amount); ?>" id="paid_salary">
                    </tr>
                    <?php
                        $total += $item->amount;
                    ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td colspan="2" class="text-right"><strong>Total</strong> </td>
                    <td><strong> <?php echo e($total); ?> </strong></td>
                </tr>
                <?php else: ?>
                    <tr>
                        <td colspan="3" class="text-center">Not Paid Yet !</td>
                    </tr>
                <?php endif; ?>
            </table>
        </div>
    </div>
    </div>


<?php /**PATH C:\Users\needtechnosoft 2\OneDrive\Desktop\laravel pojects\dairy\resources\views/admin/emp/salarypay/list.blade.php ENDPATH**/ ?>