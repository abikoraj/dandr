<tr id="item-<?php echo e($item->id); ?>" data-name="<?php echo e($item->title); ?>">
    <td><?php echo e($item->title); ?></td>
    <td><?php echo e($item->number); ?></td>
    <td><?php echo e($item->cost_price); ?></td>
    <td><?php echo e($item->sell_price); ?></td>
    <td><?php echo e($item->stock); ?></td>
    <td><?php echo e($item->unit); ?></td>
    <td><?php echo e($item->reward_percentage); ?></td>
    <td>
        <button  class="btn btn-primary btn-sm"  onclick="initEdit(<?php echo e($item->id); ?>);" >Edit</button>
        <button class="btn btn-danger btn-sm" onclick="removeData(<?php echo e($item->id); ?>);">Delete</button>
    </td>
</tr>
<?php /**PATH C:\Users\needtechnosoft 2\OneDrive\Desktop\laravel pojects\dairy\resources\views/admin/item/single.blade.php ENDPATH**/ ?>