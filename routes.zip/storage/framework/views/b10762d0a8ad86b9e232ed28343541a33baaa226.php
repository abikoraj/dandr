<div class="pt-2 pb-2">
    <input type="text" id="sid" placeholder="Search" class="form-control">
</div>
<div class="table-responsive">
    <table class="table table-bordered">
        <thead>
            <tr>
                <th>No.</th>
                <th>Farmer Name</th>
            </tr>
        </thead>
        <tbody id="farmerData">
            <?php $__currentLoopData = $farmers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr id="farmer-<?php echo e($u->no); ?>" data-name="<?php echo e($u->name); ?>" onclick="farmerSelected(<?php echo e($u->no); ?>);">
                <td class="p-1"><span style="cursor: pointer;"><?php echo e($u->no); ?></span></td>
                <td class="p-1"> <span style="cursor: pointer;"><?php echo e($u->name); ?></span></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php /**PATH C:\Users\needtechnosoft 2\OneDrive\Desktop\laravel pojects\dairy\resources\views/admin/farmer/minlist.blade.php ENDPATH**/ ?>