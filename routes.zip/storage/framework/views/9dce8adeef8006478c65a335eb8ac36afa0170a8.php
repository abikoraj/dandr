<?php $__currentLoopData = $advs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $adv): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php if($adv->user->role == 1): ?>
<tr id="advance-<?php echo e($adv->id); ?>" data-name="<?php echo e($adv->name); ?>" class="searchable">
    <td><?php echo e($adv->user->no); ?></td>
    <td><?php echo e($adv->user->name); ?></td>
    <td><?php echo e($adv->amount); ?> </td>
    <td>
        <button  type="button" data-advance="<?php echo e($adv->toJson()); ?>" class="btn btn-primary btn-sm editfarmer" onclick="initEdit(this);" >Edit</button>

        <button class="btn btn-danger btn-sm" onclick="removeData(<?php echo e($adv->id); ?>);">Delete</button></td>
</tr>
<?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH C:\Users\needtechnosoft 2\OneDrive\Desktop\laravel pojects\dairy\resources\views/admin/farmer/advance/list.blade.php ENDPATH**/ ?>