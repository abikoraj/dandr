<aside id="leftsidebar" class="sidebar">
    <div class="navbar-brand">
        <button class="btn-menu ls-toggle-btn" type="button"><i class="zmdi zmdi-menu"></i></button>
        <a href="index.html"><img src="<?php echo e(asset('backend/images/logo.svg')); ?>" width="25" alt="Aero"><span class="m-l-10">Dairy Management</span></a>
    </div>
    <div class="menu">
        <ul class="list">
            <li>
                <div class="user-info">
                    <a class="image" href="#"><img src="<?php echo e(asset('backend/images/user.png')); ?>" alt="User"></a>
                    <div class="detail">
                        <h4><?php echo e(Auth::user()->name); ?></h4>
                        <?php if(env('authphone','9852059717')==Auth::user()->phone): ?>
                            <small>Super Admin</small>
                        <?php else: ?>
                            <small>Admin</small>
                        <?php endif; ?>
                    </div>
                </div>
            </li>
            

            <li class="active open"><a href="<?php echo e(route('admin.dashboard')); ?>"><i class="zmdi zmdi-home"></i><span>Dashboard</span></a></li>
            <li><a href="javascript:void(0);" class="waves-effect waves-block menu-toggle"><i class="zmdi zmdi-apps"></i><span>Farmer</span></a>
                <ul class="ml-menu">
                    <li><a href="<?php echo e(route('admin.farmer.list')); ?>" class="waves-effect waves-block">Farmer List</a></li>
                    <li><a href="<?php echo e(route('admin.farmer.advance')); ?>" class="waves-effect waves-block">Advance</a></li>
                    <li><a href="<?php echo e(route('admin.farmer.due')); ?>" class="waves-effect waves-block">Paid By Former</a></li>
                    <li><a href="<?php echo e(route('admin.farmer.due.add.list')); ?>" class="waves-effect waves-block">Account Opening</a></li>
                    <li><a href="<?php echo e(route('admin.farmer.milk.payment.index')); ?>" class="waves-effect waves-block">Milk Payment</a></li>
                    <li><a href="<?php echo e(route('admin.sell.item.index')); ?>" class="waves-effect waves-block">Farmer Sell</a></li>

                </ul>
            </li>

            <li><a href="javascript:void(0);" class="waves-effect waves-block menu-toggle"><i class="zmdi zmdi-shopping-cart"></i><span>Milk Collection</span></a>
                <ul class="ml-menu">
                    <li><a href="<?php echo e(route('admin.center.index')); ?>" class="waves-effect waves-block">Manage Collection Center</a></li>
                    <li><a href="<?php echo e(route('admin.milk.index')); ?>" class="waves-effect waves-block"> Milk Collection</a></li>
                    <li><a href="<?php echo e(route('admin.snf-fat.index')); ?>" class="waves-effect waves-block">Add Fat & Snf</a></li>
                </ul>
            </li>
            <li><a href="javascript:void(0);" class="waves-effect waves-block menu-toggle"><i class="zmdi zmdi-shopping-cart"></i><span>Items</span></a>
                <ul class="ml-menu">
                    <li><a href="<?php echo e(route('admin.item.index')); ?>" class="waves-effect waves-block">Items</a></li>
                </ul>
            </li>
            
            <li><a href="javascript:void(0);" class="waves-effect waves-block menu-toggle"><i class="zmdi zmdi-shopping-cart"></i><span>Distributers</span></a>
                <ul class="ml-menu">
                    <li><a href="<?php echo e(route('admin.distributer.index')); ?>" class="waves-effect waves-block">Distributer List</a></li>
                    <li><a href="<?php echo e(route('admin.distributer.sell')); ?>" class="waves-effect waves-block">Distributer Sell</a></li>
                    <li><a href="<?php echo e(route('admin.distributer.payemnt')); ?>" class="waves-effect waves-block">payment</a></li>
                    <li><a href="<?php echo e(route('admin.distributer.detail.opening')); ?>" class="waves-effect waves-block">Account Opening</a></li>
                    <li><a href="<?php echo e(route('admin.distributer.request')); ?>" class="waves-effect waves-block">Distributor Request</a></li>
                </ul>
            </li>
            <li><a href="javascript:void(0);" class="waves-effect waves-block menu-toggle"><i class="zmdi zmdi-shopping-cart"></i><span>Manage Expense</span></a>
                <ul class="ml-menu">
                    <li><a href="<?php echo e(route('admin.expense.category')); ?>" class="waves-effect waves-block"><span>Expense Categories</span></a></li>
                    <li><a href="<?php echo e(route('admin.expense.index')); ?>" class="waves-effect waves-block"><span>Expenses</span></a></li>
                </ul>
            </li>
            <li><a href="javascript:void(0);" class="waves-effect waves-block menu-toggle"><i class="zmdi zmdi-shopping-cart"></i><span>Suppliers</span></a>
                <ul class="ml-menu">
                    <li><a href="<?php echo e(route('admin.supplier.index')); ?>" class="waves-effect waves-block">Supplier List</a></li>
                    <li><a href="<?php echo e(route('admin.supplier.bill')); ?>" class="waves-effect waves-block">Supplier Bill</a></li>
                    <li><a href="<?php echo e(route('admin.supplier.pay')); ?>" class="waves-effect waves-block">Supplier Payment</a></li>
                    <li><a href="<?php echo e(route('admin.supplier.previous.balance')); ?>" class="waves-effect waves-block">Previous Blance</a></li>
                </ul>
            </li>
            <li><a href="javascript:void(0);" class="waves-effect waves-block menu-toggle"><i class="zmdi zmdi-shopping-cart"></i><span>Staff Manage</span></a>
                <ul class="ml-menu">
                    <li><a href="<?php echo e(route('admin.employee.index')); ?>" class="waves-effect waves-block">Employees </a></li>
                    <li><a href="<?php echo e(route('admin.employee.account.index')); ?>" class="waves-effect waves-block">Account Opening</a></li>
                    <li><a href="<?php echo e(route('admin.employee.advance')); ?>" class="waves-effect waves-block">Advance</a></li>
                    <li><a href="<?php echo e(route('admin.salary.pay')); ?>" class="waves-effect waves-block">Salary Pay</a></li>
                </ul>
            </li>

            
        </ul>
    </div>
</aside>
<?php /**PATH C:\Users\needtechnosoft 2\OneDrive\Desktop\laravel pojects\dairy\resources\views/admin/layouts/menu.blade.php ENDPATH**/ ?>