

    <tr id="sell-<?php echo e($sell->id); ?>"   data-name="<?php echo e($sell->name); ?>" class="searchable ">
        <td><?php echo e($sell->name); ?></td>
        <td><?php echo e($sell->title); ?></td>
        <td><?php echo e($sell->rate); ?></td>
        <td><?php echo e($sell->qty); ?></td>
        <td><?php echo e($sell->total); ?></td>
        <td><?php echo e($sell->paid); ?></td>
        <td><?php echo e($sell->due); ?></td>
        <td>
            <button class="btn btn-danger btn-sm" onclick="removeData(<?php echo e($sell->id); ?>);">Delete</button></td>
    </tr>

<?php /**PATH C:\Users\needtechnosoft 2\OneDrive\Desktop\laravel pojects\dairy\resources\views/admin/distributer/sell/single.blade.php ENDPATH**/ ?>