<tr id="ledger-<?php echo e($d->id); ?>">
    <td>
        <?php echo e($d->user->distributer()->id); ?>

    </td>
    <td>
        <?php echo e($d->user->name); ?>

    </td>
    <td>
        <?php echo e((float)$d->amount); ?> <?php echo e($d->type==1?"CR":"DR"); ?>

    </td>
    <td>
        <button class="btn btn-primary" onclick="initEditLedger('Edit Account Opening Amount',<?php echo e($d->id); ?>);">Edit
        <?php if($d->user->ledgers->count()<=1): ?>
            <button class="btn btn-danger" onclick="deleteLedger(<?php echo e($d->id); ?>,removeLedger);">Delete
        <?php else: ?>

        <?php endif; ?>
    </td>

</tr>

<?php /**PATH C:\Users\needtechnosoft 2\OneDrive\Desktop\laravel pojects\dairy\resources\views/admin/distributer/balance/single.blade.php ENDPATH**/ ?>