<tr id="center-<?php echo e($product->id); ?>" data-name="<?php echo e($product->name); ?>">
    <form action="#" id="collectionForm-<?php echo e($product->id); ?>">
        <td><?php echo csrf_field(); ?><?php echo e($product->id); ?></td>
        <input type="hidden" name="id" value="<?php echo e($product->id); ?>">
        <td><input type="text" value="<?php echo e($product->name); ?>" class="form-control" name="name" form="collectionForm-<?php echo e($product->id); ?>"></td>
        <td><input type="number" value="<?php echo e($product->price); ?>" class="form-control" name="price" form="collectionForm-<?php echo e($product->id); ?>"></td>
        <td><input type="text" value="<?php echo e($product->unit); ?>" id="fatrate" step="0.001" class="form-control" name="unit" form="collectionForm-<?php echo e($product->id); ?>"></td>
        <td><input type="text" value="<?php echo e($product->stock); ?>" id="fatrate" step="0.001" class="form-control" name="stock" form="collectionForm-<?php echo e($product->id); ?>"></td>
        <td><span onclick="update(<?php echo e($product->id); ?>);" form="collectionForm-<?php echo e($product->id); ?>" class="btn btn-primary btn-sm"> Update </span> <span class="btn btn-danger btn-sm" onclick="del(<?php echo e($product->id); ?>);">Delete</span></td>
    </form>
</tr>
<?php /**PATH C:\Users\needtechnosoft 2\OneDrive\Desktop\laravel pojects\dairy\resources\views/admin/products/single.blade.php ENDPATH**/ ?>