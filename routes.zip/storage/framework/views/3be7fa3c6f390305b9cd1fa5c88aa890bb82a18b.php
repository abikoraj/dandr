<?php $__currentLoopData = $billItem; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td><?php echo e($item->title); ?></td>
        <td><?php echo e($item->rate); ?></td>
        <td><?php echo e($item->qty); ?></td>
        <td><?php echo e($item->rate * $item->qty); ?></td>
    </tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH C:\Users\needtechnosoft 2\OneDrive\Desktop\laravel pojects\dairy\resources\views/admin/supplier/bill/item.blade.php ENDPATH**/ ?>