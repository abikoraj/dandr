<?php $__currentLoopData = $bills; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bill): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<tr id="supplier-bill-<?php echo e($bill->id); ?>" data-name="<?php echo e($bill->user->name); ?>" data-billno="<?php echo e($bill->billno); ?>" class="searchable">
    <td><?php echo e(_nepalidate($bill->date)); ?></td>
    <td><?php echo e($bill->user->name); ?></td>
    <td><?php echo e($bill->billno); ?></td>
    <td><?php echo e($bill->transport_charge); ?></td>
    <td><?php echo e($bill->total); ?></td>
    <td><?php echo e($bill->paid); ?></td>
    <td><?php echo e($bill->total - $bill->paid); ?></td>
    <td>
        <button  type="button" class="btn btn-primary btn-sm editfarmer" onclick="showItems(<?php echo e($bill->id); ?>);" >View Items</button>
        <button class="btn btn-danger btn-sm" onclick="removeData(<?php echo e($bill->id); ?>);">Delete</button>
    </td>
</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH C:\Users\needtechnosoft 2\OneDrive\Desktop\laravel pojects\dairy\resources\views/admin/supplier/bill/list.blade.php ENDPATH**/ ?>