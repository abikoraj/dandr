
<?php $__env->startSection('title','Supplier Details'); ?>
<?php $__env->startSection('css'); ?>
<link rel="stylesheet" href="<?php echo e(asset('calender/nepali.datepicker.v3.2.min.css')); ?>" />
<?php $__env->stopSection(); ?>
<?php $__env->startSection('head-title'); ?>
<a href="<?php echo e(route('admin.supplier.index')); ?>">Suppliers</a> / Details / <?php echo e($user->name); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('toobar'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div >
   <?php echo $__env->make('admin.layouts.daterange', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="row">
        <div class="col-md-3">
            <span class="btn btn-primary" onclick="loadData()"> Load </span>
        </div>

    </div>
    
</div>
<div id="allData">

</div>
<?php echo $__env->make('admin.distributer.balance.change', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('admin.distributer.balance.sellitem_change', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('admin.distributer.balance.payment_change', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<script src="<?php echo e(asset('backend/plugins/select2/select2.min.js')); ?>"></script>
<script src="<?php echo e(asset('calender/nepali.datepicker.v3.2.min.js')); ?>"></script>
<script>
    



    function loadData(){
        var user = <?php echo e($user->id); ?>;
        console.log(user);
        var data={
            'year':$('#year').val(),
            'month':$('#month').val(),
            'session':$('#session').val(),
            'week':$('#week').val(),
            'center_id':$('#center_id').val(),
            'date1':$('#date1').val(),
            'date2': $('#date2').val(),
            'type':$('#type').val(),
            'user_id':<?php echo e($user->id); ?>

        };
        axios({
                method: 'post',
                url: '<?php echo e(route("admin.distributer.detail.load")); ?>',
                data:data ,
        })
        .then(function(response) {
            $('#allData').html(response.data);
        })
        .catch(function(response) {
            //handle error
            console.log(response);
        });
    }

    window.onload = function() {

        $('#type').val(0).change();
        loadData();
    };


 
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\needtechnosoft 2\OneDrive\Desktop\laravel pojects\dairy\resources\views/admin/supplier/detail.blade.php ENDPATH**/ ?>