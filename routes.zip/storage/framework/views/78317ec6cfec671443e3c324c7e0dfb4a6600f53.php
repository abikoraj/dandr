<div class="distviwer">
    <div class="pb-3 text-right">
        <span class="btn btn-danger btn-sm" onclick="hideCustomer();">X</span>
    </div>
    <table class="w-100 prodtable">
        <tr>
            <th>Itemno</th>
            <th>Name</th>
        </tr>
        <?php $__currentLoopData = \App\Models\Distributer::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dis): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr  class="hovertr" id="distri_<?php echo e($dis->id); ?>" data-distributor="<?php echo e($dis->toJson()); ?>" onclick="selectCustomer(<?php echo e($dis->id); ?>,'<?php echo e($dis->user->name); ?>')">
            <td><?php echo e($dis->id); ?></td>
            <td><?php echo e($dis->user->name); ?></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
</div>
<?php /**PATH C:\Users\needtechnosoft 2\OneDrive\Desktop\laravel pojects\dairy\resources\views/admin/billing/distributors.blade.php ENDPATH**/ ?>