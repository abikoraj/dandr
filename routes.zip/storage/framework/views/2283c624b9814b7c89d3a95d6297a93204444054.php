<tr id="advance-<?php echo e($adv->id); ?>" data-name="<?php echo e($adv->name); ?>" class="searchable">
    <td><?php echo e($adv->user->no); ?></td>
    <td><?php echo e($adv->user->name); ?></td>
    <td><?php echo e($adv->amount); ?> </td>
    <td>
        <button  type="button" data-advance="<?php echo e($adv->toJson()); ?>" class="btn btn-primary btn-sm editfarmer" onclick="initEdit(this);" >Edit</button>
        <button class="btn btn-danger btn-sm" onclick="deleteLedger(<?php echo e($adv->id); ?>,removeData);">Delete</button></td>
</tr>
<?php /**PATH C:\Users\needtechnosoft 2\OneDrive\Desktop\laravel pojects\dairy\resources\views/admin/farmer/advance/single.blade.php ENDPATH**/ ?>