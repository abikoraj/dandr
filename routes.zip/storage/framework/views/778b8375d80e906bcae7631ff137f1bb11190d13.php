
<tr id="snffat_<?php echo e($snffat->id); ?>" data-snf="<?php echo e($snffat->snf??0); ?>" data-fat="<?php echo e($snffat->fat??0); ?>">
    <td><?php echo e($snffat->no); ?></td>
    <td id="<?php echo e($snffat->id); ?>_fat" ><?php echo e($snffat->fat??0); ?></td>
    <td id="<?php echo e($snffat->id); ?>_snf" ><?php echo e($snffat->snf??0); ?></td>
    <td>
        <button class="btn btn-primary" data-snffat="<?php echo e($snffat->toJson()); ?>" onclick="showSnfFatUpdate(this)">
            Edit
        </button>
        <button class="btn btn-danger" data-snffat="<?php echo e($snffat->toJson()); ?>" onclick="delSnfFat(this);">
            delete
        </button>
    </td>
</tr>
<?php /**PATH C:\Users\needtechnosoft 2\OneDrive\Desktop\laravel pojects\dairy\resources\views/admin/snf/single.blade.php ENDPATH**/ ?>