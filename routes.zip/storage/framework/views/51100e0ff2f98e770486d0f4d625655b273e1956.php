<?php
$total = 0;
?>
<h5  >
    <?php echo $title; ?>

</h5>
<hr>
<div class="row">
    <div class="col-md-4 ">
        <input type="text" id="sid" placeholder="Search" class="form-control">

    </div>
</div>
<hr>
<table id="newstable1" class="table table-bordered table-striped table-hover js-basic-example dataTable">
    <thead>
        <tr>
            <th>Title</th>
            <th>Date</th>
            <th>Paid By</th>
            <th>Amount (Rs.)</th>
            <th>Payment Detail</th>
            <th>Remarks</th>
            <th>Action</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $exps; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $exp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr id="expense-<?php echo e($exp->id); ?>" data-name="<?php echo e($exp->title); ?>" class="searchable">
                <td><?php echo e($exp->title); ?></td>
                <td><?php echo e(_nepalidate($exp->date)); ?></td>
                <td><?php echo e($exp->payment_by); ?></td>
                <td><?php echo e($exp->amount); ?></td>
                <td><?php echo e($exp->payment_detail); ?></td>
                <td><?php echo e($exp->remark); ?></td>
                <td>
                    <button type="button" class="btn btn-primary btn-sm"
                        onclick="initEdit('<?php echo e($exp->title); ?>',<?php echo e($exp->id); ?>);">Edit</button>
                    |
                    <button class="btn btn-danger btn-sm" onclick="removeData(<?php echo e($exp->id); ?>);">Delete</button>
                </td>
            </tr>
            <?php
                $total += $exp->amount;
            ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td class="text-right" colspan="3"><strong>Total</strong></td>
            <td colspan="4"><strong>Rs.<?php echo e($total); ?></strong></td>
        </tr>
    </tbody>
</table>
<?php /**PATH C:\Users\needtechnosoft 2\OneDrive\Desktop\laravel pojects\dairy\resources\views/admin/expense/list.blade.php ENDPATH**/ ?>