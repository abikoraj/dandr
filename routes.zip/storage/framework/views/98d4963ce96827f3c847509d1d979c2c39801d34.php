<?php $__currentLoopData = $distributer; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr id="distributer-<?php echo e($user->id); ?>" data-name="<?php echo e($user->name); ?>" class="searchable">
        <td><?php echo e($user->dis_id); ?></td>
        <td><?php echo e($user->name); ?></td>
        <td><?php echo e($user->phone); ?></td>
        <td><?php echo e($user->address); ?></td>
        
        <td>
            <button type="button" data-distributer="<?php echo e($user->toJson()); ?>" data-rate="<?php echo e($user->distributer()->rate); ?>" data-amount="<?php echo e($user->distributer()->amount); ?>" class="btn btn-primary btn-sm" onclick="initEdit(this);">Edit</button>
            |
            <a href="<?php echo e(route('admin.distributer.detail',$user->id)); ?>" class="btn btn-primary btn-sm">View</a>
            |
            <button class="btn btn-danger btn-sm" onclick="removeData(<?php echo e($user->id); ?>);">Delete</button></td>
    </tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH C:\Users\needtechnosoft 2\OneDrive\Desktop\laravel pojects\dairy\resources\views/admin/distributer/list.blade.php ENDPATH**/ ?>