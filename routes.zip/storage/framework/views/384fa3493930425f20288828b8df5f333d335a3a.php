<style>
    .d-print-show{
        display:none !important;
    }

</style>
<div class="row">
    

    <div class="col-md-12 mt-3">
        <div style="border: 1px solid rgb(136, 126, 126); padding:1rem;">
            <strong>Ledger</strong> <span class="btn btn-success" onclick="printDiv('ledger');">Print</span>
            <hr>

            <div id="ledger">
                <div class="d-print-show">
                    <style>
                        @media  print {
                            td{
                                font-size: 1.2rem !important;
                                font-weight: 600 !important;
                            }


                            th:last-child, td:last-child {
                                display: none;
                            }

                        }
                        td,th{
                            border:1px solid black !important;
                            padding:2px !important;
                            font-weight: 600 !important;
                        }

                        table{
                            width:100%;
                            border-collapse: collapse;
                        }
                        thead {display: table-header-group;}
                        tfoot {display: table-header-group;}
                        .d-show-rate{

                            <?php if(env('showdisrate',0)==1): ?>
                                display:inline;
                            <?php else: ?>
                                display:none !important;
                            <?php endif; ?>
                        }
                    </style>
                    <h2 style="text-align: center;margin-bottom:0px;font-weight:800;font-size:2rem;">
                        <?php echo e(env('APP_NAME','Dairy')); ?> <br>

                    </h2>

                    <div style="font-weight:800;text-align:center;">
                        <span class="mx-3">  Ledger For : <?php echo e($user->name); ?> , </span>
                        <?php echo $title; ?>

                    </div>
                </div>
                <table class="table table-bordered table-striped table-hover js-basic-example dataTable" >
                    <tr>
                        <th>Date</th>
                        <th>Particular</th>
                        <th>Cr. (Rs.)</th>
                        <th>Dr. (Rs.)</th>
                        <th>Balance (Rs.)</th>

                    </tr>

                    <?php $__currentLoopData = $ledgers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $l): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr data-id="ledger<?php echo e($l->id); ?>">
                            <td><?php echo e(_nepalidate($l->date)); ?></td>
                            <td><?php echo $l->title; ?></td>

                            <td>
                                <?php if($l->type==1): ?>
                                    <?php echo e($l->amount); ?>

                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if($l->type==2): ?>
                                <?php echo e($l->amount); ?>

                                <?php endif; ?>
                            </td>
                            <td>
                                <?php echo e((($l->dr == null)|| ($l->dr<=0))?"":"Dr. ".$l->dr); ?>

                                <?php echo e((($l->cr == null)|| ($l->cr<=0))?"":"Cr. ".$l->cr); ?>

                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </table>
            </div>
        </div>
    </div>
</div>

<?php /**PATH C:\Users\needtechnosoft 2\OneDrive\Desktop\laravel pojects\dairy\resources\views/admin/emp/data1.blade.php ENDPATH**/ ?>