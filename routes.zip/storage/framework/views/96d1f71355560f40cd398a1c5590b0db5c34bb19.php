<div class="prodviwer">
    <table class="w-100 prodtable">
        <tr>
            <th>Itemno</th>
            <th>Name</th>
            <th>Rate</th>
        </tr>
        <?php $__currentLoopData = \App\Models\Product::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr  class="hovertr" id="prod_<?php echo e($product->id); ?>" data-product="<?php echo e($product->toJson()); ?>">
            <td><?php echo e($product->id); ?></td>
            <td><?php echo e($product->name); ?></td>
            <td><?php echo e($product->price); ?></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
</div>
<?php /**PATH C:\Users\needtechnosoft 2\OneDrive\Desktop\laravel pojects\dairy\resources\views/admin/billing/products.blade.php ENDPATH**/ ?>