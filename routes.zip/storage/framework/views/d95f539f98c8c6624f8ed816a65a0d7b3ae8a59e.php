<tr id="employee-<?php echo e($user->id); ?>" data-name="<?php echo e($user->name); ?>" class="searchable">
    <td><?php echo e($user->id); ?></td>
    <td><?php echo e($user->name); ?></td>
    <td><?php echo e($user->phone); ?></td>
    <td><?php echo e($user->address); ?></td>
    <td><?php echo e($user->employee()->salary); ?></td>
    <td>
        <button  type="button" data-employee="<?php echo e($user->toJson()); ?>" data-acc="<?php echo e($user->employee()->acc); ?>" data-salary="<?php echo e($user->employee()->salary); ?>" class="btn btn-primary btn-sm" onclick="initEdit(this);" >Edit</button>
        |
        <a href="<?php echo e(route('admin.employee.detail',$user->id)); ?>" class="btn btn-primary btn-sm">View</a>
        |
        <button class="btn btn-danger btn-sm" onclick="removeData(<?php echo e($user->id); ?>);">Delete</button></td>
</tr>
<?php /**PATH C:\Users\needtechnosoft 2\OneDrive\Desktop\laravel pojects\dairy\resources\views/admin/emp/single.blade.php ENDPATH**/ ?>