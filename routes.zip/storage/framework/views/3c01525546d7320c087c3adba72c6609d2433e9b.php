
<?php $__env->startSection('title','Dashboard'); ?>
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-2 section href" data-target="<?php echo e(route('admin.farmer')); ?>">
            <span class="icon">
                <i class="zmdi zmdi-accounts"></i>
            </span>
            <span class="divider"></span>
            <span class="text">
                Farmers (<?php echo e(\App\Models\User::where('role',1)->count()); ?>)
            </span>
        </div>

        <div class="col-md-2 section href" data-target="<?php echo e(route('admin.farmer.advance')); ?>">
            <span class="icon">
                <i class="zmdi zmdi-money"></i>
            </span>
            <span class="divider"></span>
            <span class="text text-center">
                Farmer <br> Advance
            </span>
        </div>

        <div class="col-md-2 section href" data-target="<?php echo e(route('admin.collection')); ?>">
            <span class="icon">
                <i class="zmdi zmdi-pin"></i>
            </span>
            <span class="divider"></span>
            <span class="text text-center">
                Collection <br> Center
            </span>
        </div>

        <div class="col-md-2 section href" data-target="<?php echo e(route('admin.milk')); ?>">
            <span class="icon">
                <i class="zmdi zmdi-dns"></i>
            </span>
            <span class="divider"></span>
            <span class="text text-center">
                Milk <br> Collection
            </span>
        </div>

        <div class="col-md-2 section href" data-target="<?php echo e(route('admin.snf.fat')); ?>">
            <span class="icon">
                <i class="zmdi zmdi-dns"></i>
            </span>
            <span class="divider"></span>
            <span class="text text-center">
                Snf & Fats
            </span>
        </div>

        <div class="col-md-2 section href" data-target="<?php echo e(route('admin.item')); ?>">
            <span class="icon">
                <i class="zmdi zmdi-view-module"></i>
            </span>
            <span class="divider"></span>
            <span class="text text-center">
                Items
            </span>
        </div>

        <div class="col-md-2 section href" data-target="<?php echo e(route('admin.sell.item')); ?>">
            <span class="icon">
                <i class="zmdi zmdi-view-compact"></i>
            </span>
            <span class="divider"></span>
            <span class="text text-center">
                Sell Item
            </span>
        </div>

        <?php if(env('tier',1)==1): ?>
        <div class="col-md-2 section href" data-target="<?php echo e(route('admin.exp')); ?>">
            <span class="icon">
                <i class="zmdi zmdi-balance-wallet"></i>
            </span>
            <span class="divider"></span>
            <span class="text text-center">
                Expenses
            </span>
        </div>

        <div class="col-md-2 section href" data-target="<?php echo e(route('admin.exp')); ?>">
            <span class="icon">
                <i class="zmdi zmdi-accounts"></i>
            </span>
            <span class="divider"></span>
            <span class="text text-center">
                Suppliers (<?php echo e(\App\Models\User::where('role',3)->count()); ?>)
            </span>
        </div>

        <div class="col-md-2 section href" data-target="<?php echo e(route('admin.exp')); ?>">
            <span class="icon">
                <i class="zmdi zmdi-book"></i>
            </span>
            <span class="divider"></span>
            <span class="text text-center">
                Supplier <br> Bills
            </span>
        </div>
        <?php endif; ?>
        <div class="col-md-2 section href" data-target="<?php echo e(route('report.home')); ?>">
            <span class="icon">
                <i class="zmdi zmdi-markunread-mailbox"></i>
            </span>
            <span class="divider"></span>
            <span class="text text-center">
                Reports
            </span>
        </div>

        <div class="col-md-2 section href" data-target="<?php echo e(route('cash.flow.index')); ?>">
            <span class="icon">
                <i class="zmdi zmdi-money"></i>
            </span>
            <span class="divider"></span>
            <span class="text text-center">
                Cash <br> Flow
            </span>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\needtechnosoft 2\OneDrive\Desktop\laravel pojects\dairy\resources\views/admin/index.blade.php ENDPATH**/ ?>