<!-- Footer
  ============================================= -->
<footer id="footer" class="dark">

    <!-- Copyrights
   ============================================= -->
    <div id="copyrights">
        <div class="container">

            <div class="row col-mb-30">

                <div class="col-md-6 text-center text-md-left">
                    Copyrights &copy; 2020 All Rights Reserved by Nawadurga Dairy.<br>
                    
                </div>

                <div class="col-md-6 text-center text-md-right">
                    
                        

                    <div class="clear"></div>

                    <i class="icon-envelope2"></i> nawadurga@gmail.com <span class="middot">&middot;</span> <i
                        class="icon-headphones"></i> +977 9800000 <span class="middot">&middot;</span>
                </div>

            </div>

        </div>
    </div><!-- #copyrights end -->

</footer><!-- #footer end -->
<?php /**PATH C:\Users\needtechnosoft 2\OneDrive\Desktop\laravel pojects\dairy\resources\views/front/layouts/footer.blade.php ENDPATH**/ ?>