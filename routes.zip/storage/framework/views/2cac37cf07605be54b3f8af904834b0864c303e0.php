<div class="table-responsive" >
    <table class="table table-bordered">
        <thead>
            <tr>
                <th>Item Number</th>
                <th>Item Name</th>
            </tr>
        </thead>
        <tbody id="itemData">
            <?php $__currentLoopData = \App\Models\Item::where('farmeronly',1)->select('number','sell_price','title')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr id="item-<?php echo e($i->number); ?>" data-rate="<?php echo e($i->sell_price); ?>" data-number="<?php echo e($i->number); ?>" data-name="<?php echo e($i->title); ?>" onclick="itemSelected(this.dataset);">
                <td class="p-1"><span style="cursor: pointer;"><?php echo e($i->number); ?></span></td>
                <td class="p-1"><span style="cursor: pointer;"><?php echo e($i->title); ?></span></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php /**PATH C:\Users\needtechnosoft 2\OneDrive\Desktop\laravel pojects\dairy\resources\views/admin/item/minilist.blade.php ENDPATH**/ ?>