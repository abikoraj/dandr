<tr id="ledger-<?php echo e($ledger->id); ?>">
    <td>
        <?php echo e($ledger->no); ?>

    </td>
    <td>
        <?php echo e($ledger->name); ?>

    </td>
    <td>
        <?php echo e((float)$ledger->amount); ?> <?php echo e($ledger->type==1?"CR":"DR"); ?>

    </td>
    <td>
        <button onclick="initEditLedger('<?php echo e($ledger->title); ?>',<?php echo e($ledger->id); ?>)">
            Edit
        </button>
        <button onclick="deleteLedger(<?php echo e($ledger->id); ?>,removeData)">
            Delete
        </button>
    </td>
</tr>


<?php /**PATH C:\Users\needtechnosoft 2\OneDrive\Desktop\laravel pojects\dairy\resources\views/admin/farmer/due/list/single.blade.php ENDPATH**/ ?>