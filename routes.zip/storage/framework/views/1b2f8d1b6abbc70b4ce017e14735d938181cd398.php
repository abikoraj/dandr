
<?php $__env->startSection('title','Collection Centers'); ?>
<?php $__env->startSection('head-title','Collection Center'); ?>
<?php $__env->startSection('toobar'); ?>
<button type="button" class="btn btn-primary waves-effect m-r-20" data-toggle="modal" data-target="#largeModal">Create New Center</button>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="pt-2 pb-2">
    <input type="text" id="sid" placeholder="Search">
</div>
<div class="table-responsive">
    <table id="newstable1" class="table table-bordered table-striped table-hover js-basic-example dataTable">
        <thead>
            <tr>
                <th>#Id</th>
                <th>Center Name</th>
                <th>Center Address</th>
                <th>Fat <br> Rate (Rs.)</th>
                <th>Snf <br> Rate (Rs.)</th>
                <?php if(env('hasextra',0)==1): ?>
                    <th>
                        Bonus (%)
                    </th>
                <?php endif; ?>
                <?php if(env('usetc',0)==1): ?>
                    <th>
                        TS
                    </th>
                <?php endif; ?>
                <?php if(env('usecc',0)==1): ?>
                    <th>
                        Cooling <br>
                        Cost
                    </th>
                <?php endif; ?>
                <th>Action</th>
            </tr>
        </thead>
        <tbody id="farmerData">
            <?php $__currentLoopData = $centers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php echo $__env->make('admin.center.single',['center'=>$c], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </tbody>
    </table>
</div>


<!-- modal -->

<div class="modal fade" id="largeModal" tabindex="-1" role="dialog" data-ff="name">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="title" id="largeModalLabel">Create New Collection Centers</h4>
            </div>
            <hr>
            <div class="card">
                <div class="body">
                    <form id="form_validation" method="POST" onsubmit="return saveData(event);">
                        <?php echo csrf_field(); ?>
                        <div class="row">
                            <div class="col-lg-6">
                                <label for="name">Collection Center Name</label>
                                <div class="form-group">
                                    <input type="text" id="name" name="name" class="form-control next" data-next="address" placeholder="Collection Center Name" required>
                                </div>
                            </div>

                            <div class="col-lg-6">
                                <label for="name">Collection Center Address</label>
                                <div class="form-group">
                                    <input type="text" id="address" name="address" class="form-control next" data-next="fat-rate" placeholder="Collection Center Address" required>
                                </div>
                            </div>
                            <div class="col-lg-6">
                                <label for="name">Fat Rate</label>
                                <div class="form-group">
                                    <input type="number" id="fat-rate" name="fat_rate" class="form-control next" data-next="snf-rate" step="0.001" placeholder="Enter fat rate" required>
                                </div>
                            </div>
                            <div class="col-lg-6">
                                <label for="name">Snf Rate</label>
                                <div class="form-group">
                                    <input type="number" id="snf-rate" name="snf_rate" class="form-control" step="0.001" placeholder="Enter snf rate" required>
                                </div>
                            </div>
                            <div class="col-lg-6 <?php echo e(env('hasextra',0)==1?"":"d-none"); ?>" >
                                <label for="name">Bonus (%)</label>
                                <div class="form-group">
                                    <input type="number" id="bonus" name="bonus" class="form-control" step="0.001" placeholder="Enter Bonus" value="0" required>
                                </div>
                            </div>
                            <div class="col-lg-6 <?php echo e(env('usetc',0)==1?"":"d-none"); ?>" >
                                <label for="name">TS Commission (%)</label>
                                <div class="form-group">
                                    <input type="number" id="tc" name="tc" class="form-control" step="0.001" placeholder="Enter TC Commission" value="0" required>
                                </div>
                            </div>
                            <div class="col-lg-6 <?php echo e(env('usecc',0)==1?"":"d-none"); ?>" >
                                <label for="name">Cooling Cost (%)</label>
                                <div class="form-group">
                                    <input type="number" id="cc" name="cc" class="form-control" step="0.001" placeholder="Enter Cooling Cost" value="0" required>
                                </div>
                            </div>
                        </div>
                </div>
            </div>
            <div class="modal-footer">
                <button class="btn btn-raised btn-primary waves-effect" type="submit">Submit Data</button>
                <button type="button" class="btn btn-danger waves-effect" data-dismiss="modal">Close</button>
            </div>
            </form>
        </div>
    </div>
</div>


<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<script>
    initTableSearch('sid', 'farmerData', ['name']);

    function saveData(e) {
        e.preventDefault();
        var bodyFormData = new FormData(document.getElementById('form_validation'));
        axios({
                method: 'post',
                url: '<?php echo e(route("admin.center.add")); ?>',
                data: bodyFormData,
                headers: {
                    'Content-Type': 'multipart/form-data'
                }
            })
            .then(function(response) {
                // console.log(response);
                showNotification('bg-success', 'Collection center added successfully!');
                $('#largeModal').modal('toggle');
                $('#form_validation').trigger("reset")
                $('#farmerData').prepend(response.data);
            })
            .catch(function(response) {
                //handle error
                console.log(response);
            });
    }

    // edit data
    function editCollection(e) {
        var bodyFormData = new FormData(document.getElementById('collectionForm-' + e));
        // console.log(bodyFormData);
        axios({
                method: 'post',
                url: '<?php echo e(route('admin.center.update')); ?>',
                data: bodyFormData,
                headers: {
                    'Content-Type': 'multipart/form-data'
                }
            })
            .then(function(response) {
                // console.log(response);
                showNotification('bg-success', 'Updated successfully!');
            })
            .catch(function(response) {
                //handle error
                showNotification('bg-danger', 'You do not have authority to update !');
                console.log(response);
            });
    }

 
    function removeCenter(id) {
        if (confirm('Are you sure?')) {
            axios({
                    method: 'post',
                    url: '<?php echo e(route('admin.center.delete')); ?>',
                    data:{"id":id}
                })
                .then(function(response) {
                    // console.log(response.data);
                    $('#center-' + id).remove();
                    showNotification('bg-danger', 'Deleted Successfully !');
                })
                .catch(function(response) {
                    //handle error
                    showNotification('bg-danger', 'You do not have authority to delete !');
                    console.log(response);
                });
        }
    }
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\needtechnosoft 2\OneDrive\Desktop\laravel pojects\dairy\resources\views/admin/center/index.blade.php ENDPATH**/ ?>