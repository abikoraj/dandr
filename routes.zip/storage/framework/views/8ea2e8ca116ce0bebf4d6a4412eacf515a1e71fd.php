<tr id="farmer-<?php echo e($user->id); ?>" data-no="<?php echo e($user->no); ?>" data-name="<?php echo e($user->name); ?>" class="searchable">
    <td><?php echo e($user->no); ?></td>
    <td><?php echo e($user->name); ?></td>
    <?php if(env('requirephone',1)==1): ?>
        <td><?php echo e($user->phone); ?></td>
    <?php endif; ?>
    <td><?php echo e($user->address); ?> </td>
    <td>
        <?php if($user->amount > 0): ?>
            <?php echo e($user->amount); ?>   ( <?php echo e($user->amounttype==1?"Cr":"Dr"); ?> )
        <?php else: ?>
            --
        <?php endif; ?>
    </td>
    <td>
        <button  type="button" data-farmer="<?php echo e($user->toJson()); ?>" class="btn btn-primary btn-sm editfarmer" onclick="initEdit(this);" >Edit</button>
        |
        <a href="<?php echo e(route('admin.farmer.detail',$user->id)); ?>" class="btn btn-primary btn-sm">View</a> |
        <button class="btn btn-danger btn-sm" onclick="removeData(<?php echo e($user->id); ?>);">Delete</button></td>
</tr>
<?php /**PATH C:\Users\needtechnosoft 2\OneDrive\Desktop\laravel pojects\dairy\resources\views/admin/farmer/single.blade.php ENDPATH**/ ?>