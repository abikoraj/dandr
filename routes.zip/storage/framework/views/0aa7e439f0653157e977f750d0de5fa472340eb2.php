
<?php $__env->startSection('title','Distributer Payment'); ?>
<?php $__env->startSection('css'); ?>
<link rel="stylesheet" href="<?php echo e(asset('backend/plugins/select2/select2.css')); ?>" />
<link rel="stylesheet" href="<?php echo e(asset('calender/nepali.datepicker.v3.2.min.css')); ?>" />
<?php $__env->stopSection(); ?>
<?php $__env->startSection('head-title','Distributer Payment'); ?>
<?php $__env->startSection('toobar'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-12 bg-light pt-2">
        <form action="" id="sellitemData">
            <?php echo csrf_field(); ?>
            <div class="row">
                <div class="col-md-9">
                    <div class="form-group">
                        <label for="unumber">Distributor</label>
                        <select name="user_id" id="u_id" class="form-control show-tick ms " data-placeholder="Select" required>
                            <option value="-1"></option>
                            <?php $__currentLoopData = \App\Models\Distributer::get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($d->id); ?>" id="opt-<?php echo e($d->id); ?>" data-rate="<?php echo e($d->rate); ?>" data-qty="<?php echo e($d->amount); ?>"><?php echo e($d->user->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>
                <div class="col-md-3 mt-4">
                    <input type="button" value="Load" class="btn btn-primary btn-block" onclick="loaddata();" id="save">
                    
                </div>

            </div>
        </form>


        <div class="row">
            <div class="col-md-12">
                <div class="mt-5">
                    <div id="data">

                    </div>

                </div>
            </div>
        </div>
    </div>
</div>

<!-- edit modal -->

<?php echo $__env->make('admin.distributer.sell.editmodal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<script src="<?php echo e(asset('backend/plugins/select2/select2.min.js')); ?>"></script>
<script src="<?php echo e(asset('backend/js/pages/forms/advanced-form-elements.js')); ?>"></script>
<script src="<?php echo e(asset('calender/nepali.datepicker.v3.2.min.js')); ?>"></script>
<script>
    // $( "#x" ).prop( "disabled", true );
    initTableSearch('sId', 'sellDisDataBody', ['name']);




    // delete

    function removeData(id) {
        if (confirm('Are you sure?')) {
            axios({
                    method: 'get',
                    url: '/admin/distributer-sell-del/' + id,
                })
                .then(function(response) {
                    showNotification('bg-danger', 'Sellitem deleted successfully!');
                    $('#sell-' + id).remove();
                })
                .catch(function(response) {
                    console.log(response)
                })
        }
    }


    function calTotal() {
        $('#total').val($('#rate').val() * $('#qty').val());
        $('#due').val($('#rate').val() * $('#qty').val());
        $('#etotal').val($('#erate').val() * $('#eqty').val());
        $('#edue').val($('#erate').val() * $('#eqty').val());
    }

    function paidTotal() {
        var total = parseFloat($('#total').val());
        var paid = parseFloat($('#paid').val());
        $('#due').val(total - paid);
        var etotal = parseFloat($('#etotal').val());
        var epaid = parseFloat($('#epaid').val());
        $('#edue').val(etotal - epaid);
    }


    $('#u_id').change(function() {
        if($(this).val()!=-1){
            loaddata();
        }
   });

   function pay(){
        axios.post('<?php echo e(route("admin.distributer.pay")); ?>',{
            'id': $('#u_id').val(),
            'amount':$('#amount').val(),
            'method':$('#method').val(),
            'date': $('#nepali-datepicker').val()
        })
        .then(function(response) {
            // console.log(response.data);
            $('#data').html(response.data);
            setDate();
        })
        .catch(function(response) {
            //handle error
            console.log(response);
        });
   }

    function loaddata(){
        // $('#data').html();
        // list
        axios.post('<?php echo e(route("admin.distributer.due")); ?>',{
            'id': $('#u_id').val()

            })
        .then(function(response) {
            // console.log(response.data);
            $('#data').html(response.data);
            setDate();
        })
        .catch(function(response) {
            //handle error
            console.log(response);
        });
    }

    function checkAmount(ele){
        if(ele.max<$(ele).val()){
            alert('The Due Is Only '+ele.max);
            $(ele).val(ele.max);
        }
    }

    function setDate(){

        var month = ('0'+ NepaliFunctions.GetCurrentBsDate().month).slice(-2);
        var day = ('0' + NepaliFunctions.GetCurrentBsDate().day).slice(-2);
        $('#nepali-datepicker').val(NepaliFunctions.GetCurrentBsYear() + '-' + month + '-' + day);
        var mainInput = document.getElementById("nepali-datepicker");
        mainInput.nepaliDatePicker();
    }

    window.onload = function() {
        // var mainInput = document.getElementById("nepali-datepicker");
        // mainInput.nepaliDatePicker();
        // var edit = document.getElementById("enepali-datepicker");
        // edit.nepaliDatePicker();
        // $('#u_id').focus();
        // loaddata();
    };


    $('#paid').bind('keydown', 'return', function(e){
        saveData();
    });

</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\needtechnosoft 2\OneDrive\Desktop\laravel pojects\dairy\resources\views/admin/distributer/payment/index.blade.php ENDPATH**/ ?>