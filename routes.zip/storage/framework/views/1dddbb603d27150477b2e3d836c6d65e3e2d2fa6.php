<style>
    .table td, .table th{
        padding:0px 5px;
        vertical-align: inherit;
    }
</style><?php /**PATH C:\Users\needtechnosoft 2\OneDrive\Desktop\laravel pojects\dairy\resources\views/admin/layouts/css.blade.php ENDPATH**/ ?>