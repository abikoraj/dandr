
<?php $__env->startSection('title','Items'); ?>
<?php $__env->startSection('head-title','Items'); ?>
<?php $__env->startSection('toobar'); ?>
<button type="button" class="btn btn-primary waves-effect m-r-20" data-toggle="modal" data-target="#largeModal">Create New Item</button>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="pt-2 pb-2">
    <input type="text" id="sid" placeholder="Search">
</div>
<div class="table-responsive">
    <table id="newstable1" class="table table-bordered table-striped table-hover js-basic-example dataTable">
        <thead>
            <tr>
                <th>Item Name</th>
                <th>Item Number</th>
                <th>Cost Price</th>
                <th>sell Price </th>
                <th>Stock </th>
                <th>Unit Type</th>
                <th>Reward (%)</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody id="itemData">
            <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php echo $__env->make('admin.item.single',['item'=>$item], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php echo $__env->make('admin.item.add', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<script>
    initTableSearch('sid', 'itemData', ['name']);
    function saveData(e) {
        e.preventDefault();
        var bodyFormData = new FormData(document.getElementById('form_validation'));
        axios({
                method: 'post',
                url: '<?php echo e(route("admin.item.save")); ?>',
                data: bodyFormData,
                headers: {
                    'Content-Type': 'multipart/form-data'
                }
            })
            .then(function(response) {
                console.log(response);
                showNotification('bg-success', 'Item added successfully!');
                $('#largeModal').modal('toggle');
                $('#form_validation').trigger("reset")
                $('#itemData').prepend(response.data);
            })
            .catch(function(response) {
                showNotification('bg-danger','Item Number already exist!');
                //handle error
                console.log(response);
            });
    }

    function initEdit(id) {
        win.showPost("Edit Item","<?php echo e(route('admin.item.edit')); ?>",{"id":id});
    }

    function editData(e) {
        e.preventDefault();
        var trid = $('#eid').val();
        var dataBody = new FormData(document.getElementById('editform'));
        axios({
                method: 'post',
                url: '/admin/item-update',
                data: dataBody,
            })
            .then(function(response) {
                showNotification('bg-success', 'Item updated successfully!');
                win.hide();
                $('#item-' + trid).replaceWith(response.data);
            })
            .catch(function(response) {
                console.log(response);
            })
    }

    // delete item
    function removeData(id) {
        if (confirm('Are you sure?')) {
            axios({
                    method: 'get',
                    url: '/admin/item-delete/' + id,
                })
                .then(function(response) {
                    showNotification('bg-danger', 'Item deleted successfully!');
                    $('#item-' + id).remove();
                })
                .catch(function(response) {
                    showNotification('bg-danger','You do not have authority to delete!');

                    console.log(response)
                })
        }
    }
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\needtechnosoft 2\OneDrive\Desktop\laravel pojects\dairy\resources\views/admin/item/index.blade.php ENDPATH**/ ?>