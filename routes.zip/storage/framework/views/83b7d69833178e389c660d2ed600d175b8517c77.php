<tr id="center-<?php echo e($center->id); ?>">
    <form action="#" id="collectionForm-<?php echo e($center->id); ?>">
    <?php echo csrf_field(); ?>
        <input type="hidden" name="id" value="<?php echo e($center->id); ?>" form="collectionForm-<?php echo e($center->id); ?>">
        <td><?php echo e($center->id); ?></td>
        <td><input type="text" value="<?php echo e($center->name); ?>" id="name" class="form-control" name="name" form="collectionForm-<?php echo e($center->id); ?>"></td>
        <td><input style="min-width:200px;" type="text" value="<?php echo e($center->addresss); ?>" id="address" class="form-control" name="address" form="collectionForm-<?php echo e($center->id); ?>"></td>
        <td><input type="number" value="<?php echo e($center->fat_rate); ?>" id="fat-rate" step="0.001" class="form-control" name="fat_rate" form="collectionForm-<?php echo e($center->id); ?>"></td>
        <td><input type="number" value="<?php echo e($center->snf_rate); ?>" id="snf-rate" step="0.001" class="form-control" name="snf_rate" form="collectionForm-<?php echo e($center->id); ?>"></td>
        <?php if(env('hasextra',0)==1): ?>
            <td>
                <input type="number" value="<?php echo e($center->bonus); ?>" id="bonus" step="0.001" class="form-control" name="bonus" form="collectionForm-<?php echo e($center->id); ?>">
            </td>
        <?php endif; ?>
        <?php if(env('usetc',0)==1): ?>
            <td>
                <input type="number" value="<?php echo e($center->tc); ?>" id="tc" step="0.001" class="form-control" name="tc" form="collectionForm-<?php echo e($center->id); ?>">
            </td>
        <?php endif; ?>
        <?php if(env('usecc',0)==1): ?>
        <td>
            <input type="number" value="<?php echo e($center->cc); ?>" id="cc" step="0.001" class="form-control" name="cc" form="collectionForm-<?php echo e($center->id); ?>">
        </td>
    <?php endif; ?>
        <td><span onclick="editCollection(<?php echo e($center->id); ?>);" form="collectionForm-<?php echo e($center->id); ?>" class="btn btn-primary btn-sm"> Update </span> <br> <span class="btn btn-danger btn-sm" onclick="removeCenter(<?php echo e($center->id); ?>);">Delete</span></td>
    </form>
</tr>
<?php /**PATH C:\Users\needtechnosoft 2\OneDrive\Desktop\laravel pojects\dairy\resources\views/admin/center/single.blade.php ENDPATH**/ ?>