
<?php $__env->startSection('title','Distributers'); ?>
<?php $__env->startSection('head-title','Distributers Request'); ?>
<?php $__env->startSection('content'); ?>

<div class="table-responsive">
    <table id="newstable1" class="table table-bordered table-striped table-hover js-basic-example dataTable">
        <thead>
            <tr>
                <th>Date</th>
                <th>Distributor Name</th>
                <th>Item Name</th>
                <th>Qty (Kg/Ltr)</th>
                <th>Status</th>
            </tr>
        </thead>
        <tbody >
            <?php $__currentLoopData = $disReqs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e(_nepalidate($item->date)); ?></td>
                    <td><?php echo e($item->user->name); ?></td>
                    <td><?php echo e($item->item_name); ?></td>
                    <td><?php echo e($item->amount); ?></td>
                    <td>
                        <?php if($item->status == 0): ?>
                            <a href="<?php echo e(route('change.status',$item->id)); ?>" onclick="return confirm('Are you sure ?');" class="badge badge-primary">Pending</a>
                        <?php else: ?>
                            <span class="badge badge-success">Success</span>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>


<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\needtechnosoft 2\OneDrive\Desktop\laravel pojects\dairy\resources\views/admin/distributer/request.blade.php ENDPATH**/ ?>