
<?php $__env->startSection('title', 'Supplier Bill'); ?>
<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('backend/plugins/select2/select2.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('calender/nepali.datepicker.v3.2.min.css')); ?>" />
<?php $__env->stopSection(); ?>
<?php $__env->startSection('head-title', 'Supplier Bill'); ?>
<?php $__env->startSection('toobar'); ?>
    <button class="btn btn-primary" onclick="$('#addBill').addClass('shown');">Add Bill</button>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="row mb-2">
        <div class="col-md-12">
            <label for="name">Choose Supplier</label>
            <select name="user_id" id="supplier_id" class="form-control show-tick ms select2" data-placeholder="Select"
                required>
                <option value="-1">All</option>
                <?php $__currentLoopData = \App\Models\User::where('role', 3)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($s->id); ?>"><?php echo e($s->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
    </div>
    <?php echo $__env->make('admin.supplier.bill.add', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="pt-2 pb-2">
        <?php echo $__env->make('admin.layouts.daterange', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
    <div class="row ">
        <div class="col-md-12">
            <button class="btn btn-primary" onclick="loadData()">Load Data</button>
        </div>
    </div>
    <hr>
    <div class="pt-2 pb-2">
        <input type="text" id="sid" placeholder="Search">
    </div>
    <div class="table-responsive">
        <table id="newstable1" class="table table-bordered table-striped table-hover js-basic-example dataTable">
            <thead>
                <tr>
                    <th>Date</th>
                    <th>Supplier Name</th>
                    <th>Bill No.</th>
                    <th>Transport Charge (Rs.)</th>
                    <th>Total (Rs.)</th>
                    <th>Paid (Rs.)</th>
                    <th>Due (Rs.)</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody id="supplierBillData">

            </tbody>
        </table>
    </div>


    <!-- edit modal -->
    <div class="modal fade" id="editModal" tabindex="-1" role="dialog">
        <div class="modal-dialog modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="title" id="largeModalLabel">Bill Items</h4>
                </div>
                <hr>
                <div class="card">
                    <div class="body">
                        <div class="table-responsive">
                            <table id="newstable1"
                                class="table table-bordered table-striped table-hover js-basic-example dataTable">
                                <thead>
                                    <tr>
                                        <th>Title</th>
                                        <th>Rate</th>
                                        <th>Qty</th>
                                        <th>Total</th>
                                    </tr>
                                </thead>
                                <tbody id="billitems">

                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-danger waves-effect" data-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>
    </div>

    <?php echo $__env->make('admin.supplier.bill.addItem', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <script src="<?php echo e(asset('backend/plugins/select2/select2.min.js')); ?>"></script>
    <script src="<?php echo e(asset('backend/js/pages/forms/advanced-form-elements.js')); ?>"></script>
    <script>
        function showItems(ele) {
            axios({
                    method: 'post',
                    url: '<?php echo e(route('admin.supplier.bill.item.list')); ?>',
                    data: {
                        bill_id: ele
                    }
                })
                .then(function(response) {
                    // console.log(response.data);
                    $('#billitems').html(response.data);
                })
                .catch(function(response) {
                    //handle error
                    console.log(response);
                });
            $('#editModal').modal('show');
        }

        function saveData(e) {
            e.preventDefault();
            if ($('#supplier').val() == '') {
                alert('Please select supplier.');
                $('#supplier').focus();
                return false;
            } else {
                var bodyFormData = new FormData(document.getElementById('form_validation'));
                axios({
                        method: 'post',
                        url: '<?php echo e(route('admin.supplier.bill.add')); ?>',
                        data: bodyFormData,
                        headers: {
                            'Content-Type': 'multipart/form-data'
                        }
                    })
                    .then(function(response) {
                        console.log(response);
                        showNotification('bg-success', 'Supplier bill added successfully!');
                        $('#largeModal').modal('toggle');
                        $('#form_validation').trigger("reset")
                        $('#supplierBillData').prepend(response.data);
                        $('#item_table').empty();
                        $('#addBill').removeClass('shown');
                    })
                    .catch(function(response) {
                        //handle error
                        console.log(response);
                    });
            }
        }

        // edit data
        function editData(e) {
            if ($('#esupplier').val() == '') {
                alert('Please select supplier.');
                $('#supplier').focus();
                return false;
            }
            e.preventDefault();
            var rowid = $('#eid').val();
            var bodyFormData = new FormData(document.getElementById('editform'));
            axios({
                    method: 'post',
                    url: '<?php echo e(route('admin.supplier.bill.update')); ?>',
                    data: bodyFormData,
                    headers: {
                        'Content-Type': 'multipart/form-data'
                    }
                })
                .then(function(response) {
                    console.log(response);
                    showNotification('bg-success', 'Updated successfully!');
                    $('#editModal').modal('toggle');
                    $('#supplier-bill-' + rowid).replaceWith(response.data);
                })
                .catch(function(response) {
                    //handle error
                    console.log(response);
                });
        }

        function loadData() {

            var data={
                'year':$('#year').val(),
                'month':$('#month').val(),
                'session':$('#session').val(),
                'week':$('#week').val(),
                'center_id':$('#center_id').val(),
                'date1':$('#date1').val(),
                'date2': $('#date2').val(),
                'type':$('#type').val(),
                'user_id':$('#supplier_id').val()
            };
            axios({
                    method: 'post',
                    url: '<?php echo e(route('admin.supplier.bill.list')); ?>',
                    data:data
                })
                .then(function(response) {
                    // console.log(response.data);
                    $('#supplierBillData').html(response.data);
                    initTableSearch('sid', 'supplierBillData', ['name', 'billno']);
                })
                .catch(function(response) {
                    //handle error
                    console.log(response);
                });
        }

        // delete
        function removeData(id) {
            var dataid = id;
            if (confirm('Are you sure?')) {
                axios({
                        method: 'get',
                        url: '<?php echo e(route('admin.supplier.bill.delete')); ?>',
                        data: {
                            "id": id
                        },
                    })
                    .then(function(response) {
                        // console.log(response.data);
                        $('#supplier-bill-' + dataid).remove();
                        showNotification('bg-danger', 'Deleted Successfully !');
                    })
                    .catch(function(response) {
                        //handle error
                        console.log(response);
                    });
            }
        }
        var i = 0;
        var itemKeys = [];
        // bill items js
        function singleItemTotal() {
            $('#total').val($('#rate').val() * $('#qty').val());
        }

        function addItems() {
            if ($('#ptr').val() == "" || $('#total').val() == 0) {
                alert('Please fill the above related field');
                $("#ptr").focus();
                return false;
            }
            var item = JSON.parse($('#ptr').val());
            // console.log(item);
            html = "<tr id='row-" + i + "'>";
            html += "<td>" + item.title + "<input type='hidden' name='ptr_" + i + "' value='" + item.title +
                "' /> <input type='hidden' name='item_id_" + i + "' value='" + item.id + "' /></td>";
            html += "<td>" + $('#rate').val() + "<input type='hidden' name='rate_" + i + "' value='" + $('#rate').val() +
                "'/></td>";
            html += "<td>" + $('#qty').val() + "<input type='hidden' name='qty_" + i + "' value='" + $('#qty').val() +
                "'/></td>";
            html += "<td>" + $('#total').val() + "<input type='hidden' name='total_" + i + "' id='total_" + i +
                "' value='" + $('#total').val() + "'/></td>";
            html += "<td> <span class='btn btn-danger btn-sm' onclick='RemoveItem(" + i + ");'>Remove</span></td>";
            html += "</tr>";
            $("#item_table").append(html);
            $('#ptr').val('').change();
            $('#rate').val('0');
            $('#qty').val('1');
            $('#total').val('0');
            itemKeys.push(i);
            i += 1;
            suffle();
        }

        function suffle() {
            $("#counter").val(itemKeys.join(","));
            calculateTotal();
        }

        function calculateTotal() {
            var itotal = 0;
            for (let index = 0; index < itemKeys.length; index++) {
                const element = itemKeys[index];
                itotal += parseInt($("#total_" + element).val());;
            }
            $('#itotal').val(itotal);
        }

        function RemoveItem(i) {
            $('#row-' + i).remove();
            var index = $.inArray(i, itemKeys);
            if (index > -1) {
                itemKeys.splice(index, 1);
            }
            suffle();
        }

        // create new Items

        function createNewItem(e) {
            e.preventDefault();
            var bodyFormData = new FormData(document.getElementById('createItem'));
            axios({
                    method: 'post',
                    url: '<?php echo e(route('admin.item.save')); ?>',
                    data: bodyFormData,
                    headers: {
                        'Content-Type': 'multipart/form-data'
                    }
                })
                .then(function(response) {
                    console.log(response);
                    showNotification('bg-success', 'Item added successfully!');
                    $('#createItems').modal('toggle');
                    $('#createNewItem').trigger("reset")
                    window.location.reload();
                })
                .catch(function(response) {
                    //handle error
                    console.log(response);
                });
        }

        window.onload = function() {
            $('#type').val(0).change();
            loadData();
        };

        $('#total').bind('keydown', function() {
            addItems();
        });

    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\needtechnosoft 2\OneDrive\Desktop\laravel pojects\dairy\resources\views/admin/supplier/bill/index.blade.php ENDPATH**/ ?>