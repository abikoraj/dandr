
<?php $__env->startSection('title', 'Expense Categories'); ?>
<?php $__env->startSection('head-title'); ?>
    <a href="<?php echo e(route('admin.expense.index')); ?>">Expenses</a> / Categories
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div>
        <form action="<?php echo e(route('admin.expense.category.add')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <div class="row">
                <div class="col-lg-12">
                    <div class="form-group mb-2">
                        <label for="name">Expense Category Name</label>
                        <input type="text" id="name" name="name" class="form-control next" data-next="price"
                            placeholder="Expense Category Name" required>
                    </div>
                </div>
                <div class="col-md-3 ">
                    <button class="btn btn-primary w-100" title="Saves Expenses Category">Save Category</button>
                </div>

            </div>
        </form>
    </div>
    <hr>
    <div class="row">
        <?php $__currentLoopData = \App\Models\Expcategory::latest()->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-6 mb-3 " id="cat-<?php echo e($item->id); ?>">
                <div class="shadow p-2">

                    <form action="<?php echo e(route('admin.expense.category.update')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <label for="name-<?php echo e($item->id); ?>">Name</label>
                        <input type="hidden" name="id" value="<?php echo e($item->id); ?>">
                        <input type="text" name="name" id="name-<?php echo e($item->id); ?>" class="form-control" value="<?php echo e($item->name); ?>">
                        <div class="d-flex">
                            <button class="btn btn-primary w-50">Update</button>
                            <span class="btn btn-danger w-50 text-white" onclick="delete()">Delete</span>
                        </div>
                    </form>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\needtechnosoft 2\OneDrive\Desktop\laravel pojects\dairy\resources\views/admin/expense/category/index.blade.php ENDPATH**/ ?>