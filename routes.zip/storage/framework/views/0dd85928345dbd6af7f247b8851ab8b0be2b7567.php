<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">

    <!-- Stylesheets
 ============================================= -->
    <link
        href="https://fonts.googleapis.com/css?family=Lato:300,400,400i,700|Poppins:300,400,500,600,700|PT+Serif:400,400i&display=swap"
        rel="stylesheet" type="text/css" />
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/bootstrap.css')); ?>" type="text/css" />
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/style.css')); ?>" type="text/css" />
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/dark.css')); ?>" type="text/css" />
	<link rel="stylesheet" href="<?php echo e(asset('assets/css/swiper.css')); ?>" type="text/css" />
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/font-icons.css')); ?>" type="text/css" />
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/animate.css')); ?>" type="text/css" />
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/magnific-popup.css')); ?>" type="text/css" />

    <link rel="stylesheet" href="<?php echo e(asset('assets/css/custom.css')); ?>" type="text/css" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />

    <title><?php echo e(env('APP_NAME')); ?></title>
</head>

<body>
    <?php echo $__env->make('front.layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php echo $__env->yieldContent('content'); ?>

    <?php echo $__env->make('front.layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


    <!-- JavaScripts
 ============================================= -->
    <script src="<?php echo e(asset('assets/js/jquery.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/plugins.min.js')); ?>"></script>
    <script src="https://maps.google.com/maps/api/js?key=YOUR-API-KEY"></script>

    <!-- Footer Scripts
 ============================================= -->
    <script src="<?php echo e(asset('assets/js/functions.js')); ?>"></script>

</body>

</html>
<?php /**PATH C:\Users\needtechnosoft 2\OneDrive\Desktop\laravel pojects\dairy\resources\views/front/layouts/app.blade.php ENDPATH**/ ?>