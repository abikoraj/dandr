<tr id="ledger-<?php echo e($ledger->id); ?>">
    <td>
        <?php echo e($ledger->name); ?>

    </td>
    <td>
        <?php echo e((float)$ledger->amount); ?> <?php echo e($ledger->type==1?"CR":"DR"); ?>

    </td>
    <td>
        <button class="btn btn-primary" onclick="initEditLedger('Edit Account Opening',<?php echo e($ledger->id); ?>);">Edit</button>
        <button class="btn btn-danger" onclick="deleteLedger(<?php echo e($ledger->id); ?>,delData)">
            Delete
        </button>
    </td>
</tr>
<?php /**PATH C:\Users\needtechnosoft 2\OneDrive\Desktop\laravel pojects\dairy\resources\views/admin/supplier/previous_balance/single.blade.php ENDPATH**/ ?>