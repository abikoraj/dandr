<tr id="supplier-<?php echo e($user->id); ?>" data-name="<?php echo e($user->name); ?>" class="searchable">
    <td><?php echo e($user->id); ?></td>
    <td><?php echo e($user->name); ?></td>
    <td><?php echo e($user->phone); ?></td>
    <td><?php echo e($user->address); ?></td>
    <td>
        <button  type="button" data-supplier="<?php echo e($user->toJson()); ?>" data-id="<?php echo e($user->id); ?>"  data-phone="<?php echo e($user->address); ?>" class="btn btn-primary btn-sm" onclick="initEdit(this);" >Edit</button>
        |
        <a href="<?php echo e(route('admin.supplier.detail',$user->id)); ?>" class="btn btn-primary btn-sm">View</a> |

        <button class="btn btn-danger btn-sm" onclick="removeData(<?php echo e($user->id); ?>);">Delete</button></td>
</tr>
<?php /**PATH C:\Users\needtechnosoft 2\OneDrive\Desktop\laravel pojects\dairy\resources\views/admin/supplier/single.blade.php ENDPATH**/ ?>