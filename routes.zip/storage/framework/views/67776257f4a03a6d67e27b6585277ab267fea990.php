<tr id="itemsell-<?php echo e($sell_item->id); ?>" data-id="<?php echo e($sell_item->user->no); ?>" data-item_number="<?php echo e($sell_item->item->number); ?>">
    <td><input type="checkbox" class="ids" value="<?php echo e($sell_item->id); ?>"> <?php echo e($sell_item->user->no); ?></td>
    <td><?php echo e($sell_item->item->title); ?></td>
    <td><?php echo e($sell_item->rate); ?></td>
    <td><?php echo e($sell_item->qty); ?></td>
    <td><?php echo e($sell_item->total); ?></td>
    <td><?php echo e($sell_item->paid); ?></td>
    <td><?php echo e($sell_item->due); ?></td>
    <td>
        <button class="badge badge-danger" onclick="removeData(<?php echo e($sell_item->id); ?>);">Delete</button>
    </td>
</tr>
<?php /**PATH C:\Users\needtechnosoft 2\OneDrive\Desktop\laravel pojects\dairy\resources\views/admin/sellitem/single.blade.php ENDPATH**/ ?>