
<?php $__env->startSection('title','Farmer-Details'); ?>
<?php $__env->startSection('css'); ?>
<link rel="stylesheet" href="<?php echo e(asset('calender/nepali.datepicker.v3.2.min.css')); ?>" />
<?php $__env->stopSection(); ?>
<?php $__env->startSection('head-title'); ?>
    <a href="<?php echo e(route('admin.farmer.list')); ?>">Famers</a>/ Farmer Details - . <?php echo e($user->name); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('toobar'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<?php

?>
<?php echo $__env->make('admin.snf.update', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('admin.farmer.snippet.updatemilkdata', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<div class="row">
    <div class="col-md-3">
        <select name="year" id="year" class="form-control show-tick ms select2 load-year">
        </select>
    </div>
    <div class="col-md-3">
        <select name="month" id="month" class="form-control show-tick ms select2 load-month">
        </select>
    </div>
    <div class="col-md-3">
        <select name="session" id="session" class="form-control show-tick ms select2 load-session">
            <option value="1">1</option>
            <option value="2">2</option>
        </select>
    </div>
    <div class="col-md-3">
        <span class="btn btn-primary" onclick="loadData()"> Load </span>
        <span class="btn btn-primary" onclick="printDiv('print')"> Print </span>
    </div>
</div>
<div id="allData">

</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<script src="<?php echo e(asset('backend/plugins/select2/select2.min.js')); ?>"></script>
<script>
    



    function loadData(){

        var user = <?php echo e($user->id); ?>;
        console.log(user);
        var data={
            'user_id':user,
            'year':$('#year').val(),
            'month':$('#month').val(),
            'session':$('#session').val(),
        };
        axios({
                method: 'post',
                url: '<?php echo e(route("admin.farmer.load-session-data")); ?>',
                data:data ,
        })
        .then(function(response) {
            $('#allData').html(response.data);

            setDate('closedate');
        })
        .catch(function(response) {
            //handle error
            console.log(response);
        });
    }

    window.onload = function() {

        loadData();
    };

    function snfUpdated(data){
        loadData();
    }

    function snfDeleted(){
        datadData();
    }
     function milkUpdated(data){
        loadData();
    }

    function milkDeleted(data){
        loadData();
    }
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\needtechnosoft 2\OneDrive\Desktop\laravel pojects\dairy\resources\views/admin/farmer/detail.blade.php ENDPATH**/ ?>