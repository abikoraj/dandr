<tr id="payment-<?php echo e($payment->no); ?>" data-amount="<?php echo e((float)$payment->amount); ?>" data-id="<?php echo e($payment->id); ?>">
    <td>
        <?php echo e($payment->no); ?>

    </td>
    <td>
        <?php echo e($payment->name); ?>

    </td>
    <td>
        <input data-amount="<?php echo e((float)$payment->amount); ?>" data-id="<?php echo e($payment->id); ?>" onkeydown="amountEnter(this,event);" id="amount-<?php echo e($payment->id); ?>" type="number" min="1" class="form-control amount focus-select" value="<?php echo e((float)$payment->amount); ?>">
    </td>
    <td>
        <span class="btn btn-success" onclick="amountUpdate(<?php echo e($payment->id); ?>)">
            Update
        </span>
    </td>
</tr>
<?php /**PATH C:\Users\needtechnosoft 2\OneDrive\Desktop\laravel pojects\dairy\resources\views/admin/milk/payment/single.blade.php ENDPATH**/ ?>