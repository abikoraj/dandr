<tr id="expense-<?php echo e($exp->id); ?>" data-name="<?php echo e($exp->title); ?>" class="searchable">
    <td><?php echo e($exp->title); ?></td>
    <td><?php echo e(_nepalidate($exp->date)); ?></td>
    <td><?php echo e($exp->payment_by); ?></td>
    <td><?php echo e($exp->amount); ?></td>
    <td><?php echo e($exp->payment_detail); ?></td>
    <td><?php echo e($exp->remark); ?></td>
    <td>
        <button  type="button"  class="btn btn-primary btn-sm" onclick="initEdit('<?php echo e($exp->title); ?>',<?php echo e($exp->id); ?>);" >Edit</button>
        |
        <button class="btn btn-danger btn-sm" onclick="removeData(<?php echo e($exp->id); ?>);">Delete</button></td>
</tr>
<?php /**PATH C:\Users\needtechnosoft 2\OneDrive\Desktop\laravel pojects\dairy\resources\views/admin/expense/single.blade.php ENDPATH**/ ?>