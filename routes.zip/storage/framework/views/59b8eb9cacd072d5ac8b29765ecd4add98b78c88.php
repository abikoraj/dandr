<tr id="advancerow-<?php echo e($advance->id); ?>">
    <td><input type="text" name="title" class="form-control" id="title-<?php echo e($advance->id); ?>" value="<?php echo e($advance->title); ?>"></td>
    <td>
        <?php echo e($advance->employee->user->name); ?>


    </td>
    <td>
        <input class="form-control" type="numneric" id="amount-<?php echo e($advance->id); ?>" value="<?php echo e($advance->amount); ?>">
    </td>
    <td>
        <button class="btn btn-sm btn-success" onclick="update(<?php echo e($advance->id); ?>)">Update</button>
        <button class="btn btn-sm btn-danger" onclick="del(<?php echo e($advance->id); ?>)">Delete</button>
    </td>
</tr>
<?php /**PATH C:\Users\needtechnosoft 2\OneDrive\Desktop\laravel pojects\dairy\resources\views/admin/emp/advance/single.blade.php ENDPATH**/ ?>