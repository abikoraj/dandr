
<?php $__env->startSection('head-title'); ?>
<a href="<?php echo e(route('admin.employee.index')); ?>">Employees</a> / Account Opening
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<form id="addBalance" action="" onsubmit="return saveData(event);">
    <div class="row">
        <div class="col-md-3">
            <label for="date">Date</label>
            <input type="text" name="date" id="date" class="calender form-control" readonly required>
        </div>
        <div class="col-md-3">
            <label for="employee">Employee</label>
            <select type="text" name="employee" id="employee" class="form-control ms" required>
                <?php $__currentLoopData = $emps; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $emp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($emp->id); ?>"><?php echo e($emp->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <div class="col-md-3">
            <label for="">Balance</label>
            <input type="text" id="amount" name="amount" class="form-control next" data-target="type" required step="0.01" min="1">
        </div>
        <div class="col-md-3">
            <label for="">Balance Type</label>
                <select name="type" id="type" class="form-control  ms" required>
                    <option value="1">CR</option>
                    <option value="2">DR</option>
                </select>
        </div>
        <div class="col-md-3">
            <button class="btn btn-primary w-100" >Add Balance</button>
        </div>
    </div>
</form>
<hr>
<table class="table">
    <tr>
        <th>
            Name
        </th>
        <th>
            Amount
        </th>
        <th>

        </th>
    </tr>
    <tbody id="data">

    </tbody>
</table>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <script>
        var lock=false;
        function saveData(e){
            e.preventDefault();
            if(!lock){
                data=new FormData(document.getElementById('addBalance'));
                axios.post('<?php echo e(route('admin.employee.account.add')); ?>',data)
                .then((res)=>{
                    $('#data').prepend(res.data);
                    $('#amount').val("");
                })
                .catch((err)=>{
                    alert("Opening Balance Cannot Be added");
                })
            }
        }

        function loadData(){
            $('#data').html("");
            axios.post('<?php echo e(route('admin.employee.account.index')); ?>',{"date":$('#date').val()})
            .then((res)=>{
                $('#data').html(res.data);
            });
        }

        window.onload=()=>{
            loadData();
        };

        function removeData(id){
            $('#ledger-'+id).remove();
        }

        $('$date')
        $(selector).on('change', function () {
            
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\needtechnosoft 2\OneDrive\Desktop\laravel pojects\dairy\resources\views/admin/emp/account/index.blade.php ENDPATH**/ ?>