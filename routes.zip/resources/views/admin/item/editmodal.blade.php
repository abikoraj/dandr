<!-- edit modal -->

<div class="modal fade" id="editModal" tabindex="-1" role="dialog" data-ff="ename">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="title" id="largeModalLabel">Edit Item</h4>
            </div>
            <hr>
            <div id="econtent">
                
            </div>
        </div>
    </div>
</div>